var proxyUrl  = "http://46.137.82.174/sites/macros/_layouts/macros.proxy/Proxy.aspx";
var isInSharePoint = true;